<?php

if (isset($_POST['submit'])) {
    $user=$_POST['user'];
    $cont=$_POST['cont'];
    $userDB="pedro@gmail.com";
    $contDB="123";

    if(isset($_POST['user'])){

        if($user===$userDB){
            header("location: ../home.html");
        }
        else{
            echo'<script language="javascript">alert("Error en datos");</script';
        }
    }
}